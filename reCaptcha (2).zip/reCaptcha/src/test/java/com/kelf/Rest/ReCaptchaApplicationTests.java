package com.kelf.Rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReCaptchaApplicationTests {

	@Test
	void contextLoads() {
	}

}
